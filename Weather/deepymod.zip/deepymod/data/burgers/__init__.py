from .burgers import burgers_delta, burgers_cos, burgers_sawtooth

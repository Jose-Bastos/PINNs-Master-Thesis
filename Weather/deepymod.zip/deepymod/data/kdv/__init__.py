from .kdv import single_soliton, double_soliton
